OPEN_API_KEY_SERVER = "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"
OPEN_API_KEY_TEST = "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"
GEMINI_API_KEY = "AIzaSyCWJiAWnfCmymot9QSJSOQRfTyJOuaRd-s"

#회사 aura
NEO4J_URI="neo4j+s://f6d1c497.databases.neo4j.io"
NEO4J_USERNAME="neo4j"
NEO4J_PASSWORD="FXWCxJxBYmoadOKAFdB3eIrq1AxO3Hjld9SU_RaLr1k"
NEO4J_DATABASE="neo4j"
AURA_INSTANCEID="f6d1c497"
AURA_INSTANCENAME="SAP Master Table"

#개인 aura
# NEO4J_URI="neo4j+s://786b1308.databases.neo4j.io"
# NEO4J_USERNAME="neo4j"
# NEO4J_PASSWORD="UTg4kjhzEetP8CVoMuBsFXfu0ZpGiUQjP66sJdYBGyY"
# NEO4J_DATABASE="neo4j"
# AURA_INSTANCEID="786b1308"
# AURA_INSTANCENAME="Instance01"


NEO4J_SCHEMA = """
Node properties:
Customer {name: STRING, KUNNR: STRING, KTOKD: STRING, NAME1: STRING, NAME2: STRING, STORL: STRING, SPRAS: STRING, ANRED: STRING}
Address {name: STRING, REGIO: STRING, ORT01: STRING, ADRNR: STRING, PSTLZ: STRING}
City {name: STRING}
Country {name: STRING, REGIO: STRING}
TaxInfo {name: STRING, KUNNR: STRING, STCD2: STRING, STCD5: STRING}
Lifecycle {name: STRING, KUNNR: STRING, DUEFL: STRING, ERDAT: STRING, ERNAM: STRING}
Extra {}

Relationship properties:
LOCATED_IN {name: STRING}
HAS_TAX_INFO {name: STRING}
HAS_ADDRESS {name: STRING}
PART_OF {name: STRING}
HAS_EXTRA_INFO {name: STRING}

The relationships:
(:Customer)-[:HAS_ADDRESS]->(:Address)
(:Customer)-[:HAS_TAX_INFO]->(:TaxInfo)
(:Customer)-[:HAS_LIFECYCLE]->(:Lifecycle)
(:Customer)-[:HAS_EXTRA]->(:Extra)
(:Address)-[:IN_CITY]->(:City)
(:City)-[:PART_Of]->(:Country)
"""

NEO4J_EXAMPLES = [
    "USER_INPUT: '주소가 서울인 고객들을 보여줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address)-[:IN_CTIY]->(ci:City) WHERE ci.name = '서울' RETURN c.name",
    "USER_INPUT: '세금 정보 STCD2가 DE123456인 고객을 찾아줘' QUERY: MATCH (c:Customer)-[:HAS_TAX_INFO]->(t:TaxInfo) WHERE t.STCD2 = 'DE123456' RETURN c.name",
    "USER_INPUT: '2024년에 생성된 고객 목록 보여줘' QUERY: MATCH (c:Customer)-[:HAS_LIFECYCLE]->(l:Lifecycle) WHERE l.ERDAT STARTS WITH '2024' RETURN c.name",
    "USER_INPUT: '지역 코드가 01인 고객들의 이름과 우편번호를 보여줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address)-[:IN_CTIY]->(ci:City) WHERE ci.REGIO = '01' RETURN c.name",
    "USER_INPUT: '서울에 거주하며 우편번호가 12345인 고객을 찾아줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address)-[:IN_CTIY]->(ci:City) WHERE ci.name = '서울' AND a.PSTLZ = '12345' RETURN c.name",
    "USER_INPUT: '고객 이름과 해당 고객이 속한 국가명을 보여줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address)-[:IN_CTIY]->(ci:City)-[:PART_OF]->(co:Country) RETURN c.name",
    "USER_INPUT: '담당자가 SAPADMIN인 고객의 이름과 생성일을 보여줘' QUERY: MATCH (c:Customer)-[:HAS_LIFECYCLE]->(l:Lifecycle) WHERE l.ERNAM = 'SAPADMIN' RETURN c.name",
    "USER_INPUT: '모든 고객의 이름과 고객 유형을 보여줘' QUERY: MATCH (c:Customer) RETURN c.name",
    "USER_INPUT: '국가가 한국인 고객을 찾아줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address)-[:IN_CTIY]->(ci:City)-[:PART_OF]->(co:Country) WHERE co.LAND1 = 'KR' RETURN c.name",
    "USER_INPUT: '모든 고객과 그들의 주소를 보여줘' QUERY: MATCH (c:Customer)-[:HAS_ADDRESS]->(a:Address) RETURN c.name, a.STRAS"
]


CYPHER_TEMPLATES = """
Task: Generate a VALID Cypher statement for querying a Neo4j graph database from a user input.
---
You are a Neo4j Cypher expert.

You are given a schema for a knowledge graph and your task is to convert natural language questions into valid Cypher queries using this schema. You MUST follow the schema exactly as defined.

Do NOT invent or rename any property names, node labels, or relationship types.

---
Example paths generated in graphDB:
(:Customer)-[:HAS_ADDRESS]->(:Address)  
(:Address)-[:IN_CITY]->(:City)  
(:City)-[:PART_OF]->(:Country)  
(:Customer)-[:HAS_TAX_INFO]->(:TaxInfo)  
(:Customer)-[:HAS_LIFECYCLE]->(:Lifecycle)  
(:Customer)-[:HAS_EXTRA]->(:Extra)
---
Schema:
{schema}

Examples:
{examples}

Input:
{query_text}

Do not use any properties or relationships not included in the scehma.
Match and return relevant variables and properties clearly.
Do NOT include any explanations or comments — only return the Cypher query.
Do not include triple backticks ``` or any additional text except the generated Cypher statement in your response.

Cypher query:
"""