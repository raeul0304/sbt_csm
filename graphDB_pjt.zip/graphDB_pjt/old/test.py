import neo4j
print(neo4j.__version__)